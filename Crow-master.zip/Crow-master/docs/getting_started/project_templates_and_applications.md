Here we collect samples and applications. 

The repositories mentioned here are 3rd party owned and are not supported or managed by the CrowCpp Project.

# Template projects 

+ [https://github.com/gittiver/crow_template](https://github.com/gittiver/crow_template)
  - Features: 
    - github template repository
    - uses CPM for including crow into project
    - catch2 for testing

+ [https://github.com/seobryn/corax-template](https://github.com/seobryn/corax-template)

	- Features
		- `Scripts` to Make, Compile and Clean the build
		- `Libs` Folder to store all the external Libs, Crow is set by default.
		- Format rules using  `clang-format`
